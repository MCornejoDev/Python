# pygame_pong
Codigo de juego pong simplificado. Creador: razormist. Orginal: https://www.sourcecodester.com/tutorials/python/11866/python-pygame-simple-arcade-game.html
